window.onload = function () {
    // Our garden
    let garden = {
        // An array to store the individual flowers
        flowers: [],
        // How many flowers in the garden
        numFlowers: 50,
        grass: {
            grassColor: {
                r: 120,
                g: 180,
                b: 120,
            },
            grassDiv: document.createElement("div"),
        },

        /*sky object */
        sky: {
            // The color of the sky (background)
            skyColor: {
                r: 83,
                g: 154,
                b: 240,
            },
            //the sky element
            skyDiv: document.createElement("div"),
        },
    };
    function createAndRenderTheGarden() {
        /* note how we use dot notation....*/
        //sky
        garden.sky.skyDiv.classList.add("sky"); // adds the sky class to it
        //changing bg color of that div
        garden.sky.skyDiv.style.background = `rgb( 
        ${garden.sky.skyColor.r},
        ${garden.sky.skyColor.g},
        ${garden.sky.skyColor.b}
        )`;
        document.getElementsByTagName("main")[0].appendChild(garden.sky.skyDiv);// adding the sky to the element has tag name main


        // //sun - IN the sky
        // garden.sun.sunDiv.classList.add("sun");
        // garden.sun.sunDiv.style.background = `rgb(
        // ${garden.sun.sunColor.r},
        // ${garden.sun.sunColor.g},
        // ${garden.sun.sunColor.b}
        // )`;
        // document.getElementsByClassName("sky")[0].appendChild(garden.sun.sunDiv);// adding the sky to the element that has class name sky
        let sun = new Sun(10, 10, { r: 240, g: 206, b: 83 })
        window.addEventListener("keydown", function handleKeyDown(e) {
            //call the handleKeyDown method of class
            sun.handleKeyDownInSUn(e);
        });
        sun.renderSun();


        //grass
        garden.grass.grassDiv.classList.add("grass");
        garden.grass.grassDiv.style.background = `rgb(
        ${garden.grass.grassColor.r},
        ${garden.grass.grassColor.g},
        ${garden.grass.grassColor.b}
        )`;
        document.getElementsByTagName("main")[0].appendChild(garden.grass.grassDiv);

        // add numFlowers at one time
        for (let i = 0; i < garden.numFlowers; i++) {
            // Create variables for our arguments for clarity
            let x = Math.random() * (window.innerWidth - 100);
            let y = Math.random() * 120;
            let size = Math.random() * 30 + 50;
            let stemLength = Math.random() * 50 + 50;
            let petalColor = {//give each color a random color
                r: parseInt(Math.random() * 155) + 100,
                g: parseInt(Math.random() * 155) + 100,
                b: parseInt(Math.random() * 155) + 100,
            };

            // Create a new flower using the arguments
            let flower = new Flower(x, y, size, stemLength, petalColor);
            // Add the flower to the array of flowers
            garden.flowers.push(flower);
        }

        for (let i = 0; i < garden.numFlowers; i++) {
            // render the array of flowers
            garden.flowers[i].renderFlower();

        }
    }

    createAndRenderTheGarden();
}